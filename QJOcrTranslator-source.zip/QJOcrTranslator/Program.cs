using System.Threading;
using System.Windows.Forms;

namespace QJOcrTranslator;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        using var mutex = new Mutex(initiallyOwned: true, name: @"Local\QJOcrTranslator.SingleInstance", createdNew: out bool isFirstInstance);
        if (!isFirstInstance)
        {
            var settings = SettingsStore.Load();
            var language = UiText.Parse(settings.UiLanguage);
            MessageBox.Show(
                UiText.Get(language, "app.already"),
                UiText.Get(language, "dialog.info"),
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm(SettingsStore.Load()));
        GC.KeepAlive(mutex);
    }
}
