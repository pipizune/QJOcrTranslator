#requires -Version 5.1
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$root = Join-Path $PSScriptRoot 'models\v5'
New-Item -ItemType Directory -Force -Path $root | Out-Null
$base = 'https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.10.0'

$files = @(
    @{ Name='ch_PP-OCRv5_rec_mobile.onnx'; Url="$base/onnx/PP-OCRv5/rec/ch_PP-OCRv5_rec_mobile.onnx"; Sha256='5825fc7ebf84ae7a412be049820b4d86d77620f204a041697b0494669b1742c5' },
    @{ Name='ppocrv5_dict.txt'; Url="$base/paddle/PP-OCRv5/rec/ch_PP-OCRv5_rec_mobile/ppocrv5_dict.txt"; Sha256='d1979e9f794c464c0d2e0b70a7fe14dd978e9dc644c0e71f14158cdf8342af1b' },
    @{ Name='korean_PP-OCRv5_rec_mobile.onnx'; Url="$base/onnx/PP-OCRv5/rec/korean_PP-OCRv5_rec_mobile.onnx"; Sha256='cd6e2ea50f6943ca7271eb8c56a877a5a90720b7047fe9c41a2e541a25773c9b' },
    @{ Name='ppocrv5_korean_dict.txt'; Url="$base/paddle/PP-OCRv5/rec/korean_PP-OCRv5_rec_mobile/ppocrv5_korean_dict.txt"; Sha256='a88071c68c01707489baa79ebe0405b7beb5cca229f4fc94cc3ef992328802d7' },
    @{ Name='eslav_PP-OCRv5_rec_mobile.onnx'; Url="$base/onnx/PP-OCRv5/rec/eslav_PP-OCRv5_rec_mobile.onnx"; Sha256='08705d6721849b1347d26187f15a5e362c431963a2a62bfff4feac578c489aab' },
    @{ Name='ppocrv5_eslav_dict.txt'; Url="$base/paddle/PP-OCRv5/rec/eslav_PP-OCRv5_rec_mobile/ppocrv5_eslav_dict.txt"; Sha256='3e95f1581557162870cacdba5af91a4c6be2890710d395b0c3c7578e7ee5e6eb' }
)

foreach ($file in $files) {
    $destination = Join-Path $root $file.Name
    if (Test-Path $destination) {
        $existing = (Get-FileHash -Path $destination -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($existing -eq $file.Sha256) {
            Write-Host "Đã có và checksum đúng: $($file.Name) — bỏ qua."
            continue
        }
        Remove-Item -Force $destination
        Write-Host "File cũ sai checksum; sẽ tải lại: $($file.Name)" -ForegroundColor Yellow
    }
    Write-Host "Đang tải $($file.Name) ..."
    Invoke-WebRequest -Uri $file.Url -OutFile $destination -UseBasicParsing
    if ($file.Sha256) {
        $actual = (Get-FileHash -Path $destination -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $file.Sha256) {
            Remove-Item -Force $destination
            throw "Sai SHA256 cho $($file.Name); đã xóa file không khớp."
        }
    }
}

Write-Host "Hoàn tất. Chỉ thêm bộ Chinese, Korean, East Slavic (Russian); Latin/Vietnamese đã có trong RapidOcrNet NuGet." -ForegroundColor Green
Get-ChildItem $root | Select-Object Name, @{Name='SizeMB';Expression={[math]::Round($_.Length/1MB,2)}} | Format-Table -AutoSize
