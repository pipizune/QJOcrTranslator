# Tạo EXE Windows x64

1. Cài [.NET 8 SDK x64](https://dotnet.microsoft.com/download/dotnet/8.0) để build.
2. Mở PowerShell 5.1 ở thư mục này.
3. Chạy:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Get-LanguageModels.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Build-Windows.ps1"
```

Kết quả ở `publish\QJOcrTranslator.exe`. Máy chạy cần [.NET 8 Desktop Runtime x64](https://dotnet.microsoft.com/download/dotnet/8.0). Giữ các model dưới `publish\models\v5` cùng executable. Lần đầu cần Internet để restore NuGet và tải các model v5. PP-OCRv6 Medium không bị tải khi build; nhập/tải riêng trong Model Manager của ứng dụng.
