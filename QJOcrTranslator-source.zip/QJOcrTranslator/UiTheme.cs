using System.Drawing;
using System.Windows.Forms;

namespace QJOcrTranslator;

internal static class UiTheme
{
    public static readonly Color Background = Color.FromArgb(15, 23, 42);
    public static readonly Color Surface = Color.FromArgb(24, 35, 58);
    public static readonly Color SurfaceRaised = Color.FromArgb(32, 45, 70);
    public static readonly Color Border = Color.FromArgb(51, 65, 91);
    public static readonly Color Primary = Color.FromArgb(45, 212, 191);
    public static readonly Color PrimaryHover = Color.FromArgb(94, 234, 212);
    public static readonly Color Text = Color.FromArgb(241, 245, 249);
    public static readonly Color Muted = Color.FromArgb(160, 174, 195);
    public static readonly Color Success = Color.FromArgb(74, 222, 128);
    public static readonly Color Warning = Color.FromArgb(251, 191, 36);
    public static readonly Color Error = Color.FromArgb(248, 113, 113);

    public static void StyleButton(Button button, bool primary = false)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = primary ? 0 : 1;
        button.FlatAppearance.BorderColor = Border;
        button.FlatAppearance.MouseOverBackColor = primary ? PrimaryHover : SurfaceRaised;
        button.FlatAppearance.MouseDownBackColor = primary ? Color.FromArgb(20, 184, 166) : Border;
        button.BackColor = primary ? Primary : SurfaceRaised;
        button.ForeColor = primary ? Background : Text;
        button.Font = new Font("Segoe UI", 9.5F, primary ? FontStyle.Bold : FontStyle.Regular);
        button.Cursor = Cursors.Hand;
        button.UseVisualStyleBackColor = false;
        button.Padding = new Padding(8, 2, 8, 2);
    }

    public static void StyleLabel(Label label, bool muted = false)
    {
        label.ForeColor = muted ? Muted : Text;
        label.BackColor = Color.Transparent;
        label.Font = new Font("Segoe UI", 9F);
    }

    public static void StyleInput(Control control)
    {
        control.BackColor = SurfaceRaised;
        control.ForeColor = Text;
        control.Font = new Font("Segoe UI", 9.5F);
    }

    public static void StyleCheckBox(CheckBox checkBox)
    {
        checkBox.ForeColor = Text;
        checkBox.BackColor = Color.Transparent;
        checkBox.Font = new Font("Segoe UI", 9F);
        checkBox.Cursor = Cursors.Hand;
        checkBox.AutoSize = true;
    }

    public static Panel MakeCard()
    {
        return new Panel
        {
            BackColor = Surface,
            Padding = new Padding(16),
            Margin = new Padding(0, 0, 0, 12)
        };
    }
}
