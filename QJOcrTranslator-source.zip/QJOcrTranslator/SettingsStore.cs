using System.Text.Json;

namespace QJOcrTranslator;

internal sealed class AppSettings
{
    public string UiLanguage { get; set; } = "vi";
    public string OcrProfile { get; set; } = "v5-latin";
    public bool AutoPaste { get; set; } = true;
    public bool CopyToClipboard { get; set; } = true;
}

internal static class SettingsStore
{
    private static readonly string SettingsPath = Path.Combine(ModelCatalog.AppDataRoot, "settings.json");
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(SettingsPath))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(SettingsPath)) ?? new AppSettings();
        }
        catch { /* Restore safe defaults if the preferences file is damaged. */ }
        return new AppSettings();
    }

    public static void Save(AppSettings settings)
    {
        try
        {
            Directory.CreateDirectory(ModelCatalog.AppDataRoot);
            string temp = SettingsPath + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(settings, JsonOptions));
            File.Move(temp, SettingsPath, overwrite: true);
        }
        catch { /* Preferences are optional; don't interrupt OCR. */ }
    }
}
