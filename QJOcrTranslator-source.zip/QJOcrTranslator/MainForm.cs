using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Security;
using System.Windows.Forms;
using Microsoft.Win32;
using RapidOcrNet;
using SkiaSharp;

namespace QJOcrTranslator;

internal sealed class MainForm : Form
{
    private const string FirefoxUrl = "about:translations#src=detect&trg=vi";
    private readonly AppSettings _settings;
    private UiLanguage _uiLanguage;
    private readonly ComboBox _profileCombo = new();
    private readonly ComboBox _uiLanguageCombo = new();
    private readonly CheckBox _autoPaste = new();
    private readonly CheckBox _copyClipboard = new();
    private readonly Button _scanButton = new();
    private readonly Button _translateButton = new();
    private readonly Button _openFirefoxButton = new();
    private readonly Button _manageButton = new();
    private readonly Button _clearButton = new();
    private readonly System.Windows.Forms.TextBox _result = new();
    private readonly Label _title = new();
    private readonly Label _subtitle = new();
    private readonly Label _languageLabel = new();
    private readonly Label _profileLabel = new();
    private readonly Label _profileDescription = new();
    private readonly Label _resultTitle = new();
    private readonly Label _status = new();
    private readonly Label _privacyBadge = new();
    private readonly Label _hotkeyHint = new();
    private readonly ProgressBar _progress = new();
    private readonly NotifyIcon _tray = new();
    private RapidOcr? _ocrEngine;
    private OcrProfile? _loadedProfile;
    private bool _busy;
    private bool _refreshingCombos;

    public MainForm(AppSettings settings)
    {
        _settings = settings;
        _uiLanguage = UiText.Parse(settings.UiLanguage);
        Text = "QJ OCR";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(850, 690);
        ClientSize = new Size(940, 760);
        BackColor = UiTheme.Background;
        ForeColor = UiTheme.Text;
        Font = new Font("Segoe UI", 9F);
        AutoScaleMode = AutoScaleMode.Dpi;
        KeyPreview = true;

        BuildLayout();
        RefreshLocalizedText();
        _autoPaste.Checked = _settings.AutoPaste;
        _copyClipboard.Checked = _settings.CopyToClipboard;
        SetSelectedProfile(ModelCatalog.GetById(_settings.OcrProfile));
        BuildTrayMenu();

        Shown += (_, _) => RegisterHotkey();
        Resize += (_, _) => { if (WindowState == FormWindowState.Minimized) Hide(); };
        FormClosing += (_, e) =>
        {
            if (_busy && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                return;
            }
            _tray.Visible = false;
        };
    }

    private string T(string key) => UiText.Get(_uiLanguage, key);

    private void BuildLayout()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = 1,
            RowCount = 5,
            BackColor = UiTheme.Background
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 132));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 108));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        Controls.Add(root);

        var header = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 215));
        header.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var titlePanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = Padding.Empty };
        _title.Location = new Point(2, 0);
        _title.AutoSize = true;
        _title.Font = new Font("Segoe UI Semibold", 19F, FontStyle.Bold);
        _title.ForeColor = UiTheme.Text;
        _subtitle.Location = new Point(4, 42);
        _subtitle.AutoSize = true;
        UiTheme.StyleLabel(_subtitle, muted: true);
        titlePanel.Controls.AddRange(new Control[] { _title, _subtitle });

        var languagePanel = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent, Margin = Padding.Empty };
        _languageLabel.AutoSize = true;
        _languageLabel.Location = new Point(0, 2);
        UiTheme.StyleLabel(_languageLabel, muted: true);
        _uiLanguageCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _uiLanguageCombo.Size = new Size(195, 30);
        _uiLanguageCombo.Location = new Point(0, 25);
        _uiLanguageCombo.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        UiTheme.StyleInput(_uiLanguageCombo);
        _uiLanguageCombo.Items.AddRange(UiText.Languages.Select(UiText.NativeName).Cast<object>().ToArray());
        _uiLanguageCombo.SelectedIndex = (int)_uiLanguage;
        _uiLanguageCombo.SelectedIndexChanged += (_, _) =>
        {
            if (_refreshingCombos || _uiLanguageCombo.SelectedIndex < 0) return;
            _uiLanguage = (UiLanguage)_uiLanguageCombo.SelectedIndex;
            _settings.UiLanguage = UiText.Code(_uiLanguage);
            SaveSettings();
            RefreshLocalizedText();
            BuildTrayMenu();
        };
        languagePanel.Controls.AddRange(new Control[] { _languageLabel, _uiLanguageCombo });
        header.Controls.Add(titlePanel, 0, 0);
        header.Controls.Add(languagePanel, 1, 0);
        root.Controls.Add(header, 0, 0);

        var profileCard = UiTheme.MakeCard();
        profileCard.Dock = DockStyle.Fill;
        var profileLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 3,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        profileLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        profileLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
        profileLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 25));
        profileLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        profileLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        _profileLabel.Dock = DockStyle.Fill;
        _profileLabel.Margin = Padding.Empty;
        UiTheme.StyleLabel(_profileLabel);
        _profileCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _profileCombo.Dock = DockStyle.Fill;
        _profileCombo.Margin = new Padding(0, 3, 8, 3);
        UiTheme.StyleInput(_profileCombo);
        _profileCombo.SelectedIndexChanged += (_, _) =>
        {
            if (_refreshingCombos || _profileCombo.SelectedIndex < 0) return;
            var profile = ModelCatalog.Profiles[_profileCombo.SelectedIndex];
            _settings.OcrProfile = profile.IdText;
            SaveSettings();
            UpdateProfileDescription();
        };
        _manageButton.Dock = DockStyle.Fill;
        _manageButton.Margin = new Padding(4, 3, 0, 3);
        _manageButton.Click += (_, _) => ShowModelManager();
        UiTheme.StyleButton(_manageButton);
        _profileDescription.Dock = DockStyle.Fill;
        _profileDescription.Margin = new Padding(0, 4, 0, 0);
        _profileDescription.AutoEllipsis = true;
        UiTheme.StyleLabel(_profileDescription, muted: true);
        profileLayout.Controls.Add(_profileLabel, 0, 0);
        profileLayout.Controls.Add(_profileCombo, 0, 1);
        profileLayout.Controls.Add(_manageButton, 1, 1);
        profileLayout.Controls.Add(_profileDescription, 0, 2);
        profileLayout.SetColumnSpan(_profileDescription, 2);
        profileCard.Controls.Add(profileLayout);
        root.Controls.Add(profileCard, 0, 1);

        var actionsCard = UiTheme.MakeCard();
        actionsCard.Dock = DockStyle.Fill;
        var actionLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        actionLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actionLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        actionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        actionLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, BackColor = Color.Transparent, Padding = Padding.Empty, Margin = Padding.Empty };
        _scanButton.Size = new Size(190, 40);
        _scanButton.Margin = new Padding(0, 1, 6, 1);
        _scanButton.Click += async (_, _) => await ScanAsync();
        UiTheme.StyleButton(_scanButton, primary: true);
        _translateButton.Size = new Size(215, 40);
        _translateButton.Margin = new Padding(0, 1, 6, 1);
        _translateButton.Click += async (_, _) => await TranslateCurrentTextAsync();
        UiTheme.StyleButton(_translateButton);
        _openFirefoxButton.Size = new Size(135, 40);
        _openFirefoxButton.Margin = new Padding(0, 1, 6, 1);
        _openFirefoxButton.Click += (_, _) => OpenFirefox();
        UiTheme.StyleButton(_openFirefoxButton);
        _clearButton.Size = new Size(90, 40);
        _clearButton.Margin = new Padding(0, 1, 0, 1);
        _clearButton.Click += (_, _) => _result.Clear();
        UiTheme.StyleButton(_clearButton);
        buttons.Controls.AddRange(new Control[] { _scanButton, _translateButton, _openFirefoxButton, _clearButton });
        _autoPaste.Dock = DockStyle.Fill;
        _autoPaste.Margin = new Padding(2, 1, 4, 0);
        UiTheme.StyleCheckBox(_autoPaste);
        _autoPaste.CheckedChanged += (_, _) => { _settings.AutoPaste = _autoPaste.Checked; SaveSettings(); };
        _copyClipboard.Dock = DockStyle.Fill;
        _copyClipboard.Margin = new Padding(2, 1, 0, 0);
        UiTheme.StyleCheckBox(_copyClipboard);
        _copyClipboard.CheckedChanged += (_, _) => { _settings.CopyToClipboard = _copyClipboard.Checked; SaveSettings(); };
        actionLayout.Controls.Add(buttons, 0, 0);
        actionLayout.SetColumnSpan(buttons, 2);
        actionLayout.Controls.Add(_autoPaste, 0, 1);
        actionLayout.Controls.Add(_copyClipboard, 1, 1);
        actionsCard.Controls.Add(actionLayout);
        root.Controls.Add(actionsCard, 0, 2);

        var resultCard = UiTheme.MakeCard();
        resultCard.Dock = DockStyle.Fill;
        var resultHeader = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = Color.Transparent };
        _resultTitle.AutoSize = true;
        _resultTitle.Location = new Point(2, 7);
        _resultTitle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
        UiTheme.StyleLabel(_resultTitle);
        resultHeader.Controls.Add(_resultTitle);
        _result.Multiline = true;
        _result.AcceptsReturn = true;
        _result.AcceptsTab = true;
        _result.ScrollBars = ScrollBars.Vertical;
        _result.WordWrap = true;
        _result.Dock = DockStyle.Fill;
        _result.BorderStyle = BorderStyle.FixedSingle;
        _result.Font = new Font("Segoe UI", 11F);
        _result.BackColor = UiTheme.SurfaceRaised;
        _result.ForeColor = UiTheme.Text;
        _result.PlaceholderText = T("result.placeholder");
        resultCard.Controls.Add(_result);
        resultCard.Controls.Add(resultHeader);
        root.Controls.Add(resultCard, 0, 3);

        var footer = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 3,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 235));
        footer.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));
        footer.RowStyles.Add(new RowStyle(SizeType.Absolute, 8));
        footer.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        _status.Dock = DockStyle.Fill;
        _status.Margin = Padding.Empty;
        _status.AutoEllipsis = true;
        UiTheme.StyleLabel(_status, muted: true);
        _progress.Dock = DockStyle.Fill;
        _progress.Margin = Padding.Empty;
        _progress.Style = ProgressBarStyle.Marquee;
        _progress.MarqueeAnimationSpeed = 26;
        _progress.Visible = false;
        _hotkeyHint.Dock = DockStyle.Fill;
        _hotkeyHint.AutoEllipsis = true;
        _hotkeyHint.Margin = Padding.Empty;
        UiTheme.StyleLabel(_hotkeyHint, muted: true);
        _privacyBadge.Dock = DockStyle.Fill;
        _privacyBadge.TextAlign = ContentAlignment.MiddleRight;
        _privacyBadge.Margin = Padding.Empty;
        _privacyBadge.ForeColor = UiTheme.Success;
        footer.Controls.Add(_status, 0, 0);
        footer.SetColumnSpan(_status, 2);
        footer.Controls.Add(_progress, 0, 1);
        footer.SetColumnSpan(_progress, 2);
        footer.Controls.Add(_hotkeyHint, 0, 2);
        footer.Controls.Add(_privacyBadge, 1, 2);
        root.Controls.Add(footer, 0, 4);
    }

    private void RefreshLocalizedText()
    {
        Text = T("app.title");
        _title.Text = T("app.title");
        _subtitle.Text = T("app.subtitle");
        _languageLabel.Text = T("ui.language");
        _profileLabel.Text = T("model.label");
        _manageButton.Text = T("model.manage");
        _scanButton.Text = T("scan");
        _translateButton.Text = T("translate");
        _openFirefoxButton.Text = T("open.firefox");
        _autoPaste.Text = T("auto.paste");
        _copyClipboard.Text = T("copy.clipboard");
        _resultTitle.Text = T("result.title");
        _result.PlaceholderText = T("result.placeholder");
        _clearButton.Text = T("clear");
        _privacyBadge.Text = "●  " + T("footer.local");
        _hotkeyHint.Text = T("footer.hotkey");
        _refreshingCombos = true;
        int selected = _profileCombo.SelectedIndex;
        _profileCombo.Items.Clear();
        foreach (var profile in ModelCatalog.Profiles) _profileCombo.Items.Add(profile.Name(_uiLanguage));
        if (selected >= 0 && selected < _profileCombo.Items.Count) _profileCombo.SelectedIndex = selected;
        else _profileCombo.SelectedIndex = 0;
        _refreshingCombos = false;
        UpdateProfileDescription();
        if (string.IsNullOrEmpty(_status.Text)) _status.Text = T("footer.ready");
    }

    private void SetSelectedProfile(OcrProfile profile)
    {
        _refreshingCombos = true;
        _profileCombo.SelectedIndex = ModelCatalog.Profiles.ToList().FindIndex(p => p.Id == profile.Id);
        _refreshingCombos = false;
        _settings.OcrProfile = profile.IdText;
        UpdateProfileDescription();
    }

    private OcrProfile SelectedProfile => ModelCatalog.Profiles[Math.Max(0, _profileCombo.SelectedIndex)];

    private void UpdateProfileDescription()
    {
        if (_profileDescription is null || _profileCombo.SelectedIndex < 0) return;
        var profile = SelectedProfile;
        string description = profile.Description(_uiLanguage);
        if (profile.IsV6) description += "  " + T("model.v6notice");
        _profileDescription.Text = description;
        _profileDescription.ForeColor = profile.IsV6 ? UiTheme.Warning : UiTheme.Muted;
        if (profile.IsV6)
        {
            var paths = ModelCatalog.Resolve(profile);
            if (ModelCatalog.ArePathsPresent(paths, out _)) _status.Text = T("model.ready");
            else _status.Text = T("model.missing");
        }
        else
        {
            _status.Text = T("footer.ready");
        }
    }

    private void ShowModelManager()
    {
        using var manager = new ModelManagerForm(_uiLanguage);
        manager.ShowDialog(this);
        UpdateProfileDescription();
    }

    private void BuildTrayMenu()
    {
        _tray.ContextMenuStrip?.Dispose();
        var menu = new ContextMenuStrip { BackColor = UiTheme.Surface, ForeColor = UiTheme.Text };
        menu.Items.Add(T("app.title"), null, (_, _) => ShowMain());
        menu.Items.Add(T("scan"), null, async (_, _) => await ScanAsync());
        menu.Items.Add(T("model.manage"), null, (_, _) => ShowModelManager());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(T("clear"), null, (_, _) => _result.Clear());
        menu.Items.Add(T("app.exit"), null, (_, _) => Close());
        _tray.ContextMenuStrip = menu;
        _tray.Icon = SystemIcons.Application;
        _tray.Text = T("app.title");
        _tray.Visible = true;
        _tray.DoubleClick -= TrayDoubleClick;
        _tray.DoubleClick += TrayDoubleClick;
    }

    private void TrayDoubleClick(object? sender, EventArgs e) => ShowMain();

    private void ShowMain()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
    }

    private void RegisterHotkey()
    {
        if (!NativeHotkey.RegisterHotKey(Handle, NativeHotkey.HotkeyId, NativeHotkey.ModControl | NativeHotkey.ModAlt, (int)Keys.O))
            _status.Text = T("hotkey.unavailable");
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == NativeHotkey.WmHotkey && m.WParam.ToInt32() == NativeHotkey.HotkeyId && !_busy)
            _ = ScanAsync();
        base.WndProc(ref m);
    }

    private async Task ScanAsync()
    {
        if (_busy) return;
        var profile = SelectedProfile;
        var paths = ModelCatalog.Resolve(profile);
        if (!ModelCatalog.ArePathsPresent(paths, out string missing))
        {
            if (profile.Id == OcrProfileId.V6Medium)
            {
                var result = MessageBox.Show(this, string.Format(T("error.modelMissing"), missing), T("dialog.warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes) ShowModelManager();
            }
            else
                MessageBox.Show(this, string.Format(T("error.modelMissing"), missing), T("dialog.warning"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _busy = true;
        SetControlsBusy(true);
        _status.Text = T("state.choose");
        _progress.Visible = true;
        Hide();
        byte[]? image = null;
        try
        {
            await Task.Delay(180);
            using (var overlay = new SelectionOverlay(_uiLanguage))
            {
                var selected = overlay.ShowDialog();
                if (selected == DialogResult.OK) image = overlay.CapturePng();
            }
            ShowMain();
            if (image is null)
            {
                _status.Text = T("state.cancel");
                return;
            }

            _status.Text = T("state.ocr");
            string text = await Task.Run(() => RunOcr(image, profile, paths)).ConfigureAwait(true);
            text = text.Trim();
            if (string.IsNullOrWhiteSpace(text))
            {
                _result.Clear();
                _status.Text = T("state.noText");
                return;
            }

            _result.Text = text;
            if (_copyClipboard.Checked || _autoPaste.Checked) SetClipboardText(text);
            _status.Text = string.Format(T("state.done"), text.Length);
            if (_autoPaste.Checked)
            {
                Hide();
                await Task.Delay(300);
                bool launched = OpenFirefox();
                await Task.Delay(1300);
                bool pasted = launched && TryPasteIfFirefoxIsForeground();
                ShowMain();
                _status.Text = pasted ? T("state.pasted") : T("state.paste.manual");
            }
        }
        catch (Exception ex)
        {
            ShowMain();
            _status.Text = T("error.title");
            MessageBox.Show(this, ex.Message, T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _progress.Visible = false;
            _busy = false;
            SetControlsBusy(false);
        }
    }

    private string RunOcr(byte[] image, OcrProfile profile, OcrPaths paths)
    {
        using var bitmap = SKBitmap.Decode(image) ?? throw new InvalidDataException(T("error.imageDecode"));
        if (_ocrEngine is null || _loadedProfile?.Id != profile.Id)
        {
            _ocrEngine?.Dispose();
            _ocrEngine = new RapidOcr();
            if (profile.IsV6)
            {
                var modelSet = ModelCatalog.CreateV6ModelSet(paths);
                _ocrEngine.InitModels(modelSet, numThread: 1);
            }
            else
            {
                _ocrEngine.InitModels(paths.Detector, paths.Classifier, paths.Recognizer, paths.Dictionary, numThread: 1);
            }
            _loadedProfile = profile;
        }

        var options = profile.IsV6 ? RapidOcrOptions.PPOCRv6 : RapidOcrOptions.Default;
        return _ocrEngine.Detect(bitmap, options).StrRes;
    }

    private async Task TranslateCurrentTextAsync()
    {
        string text = _result.Text.Trim();
        if (text.Length == 0)
        {
            _status.Text = T("state.translate.empty");
            return;
        }

        try
        {
            SetClipboardText(text);
            _status.Text = T("state.translating");
            bool launched = OpenFirefox();
            if (_autoPaste.Checked)
            {
                Hide();
                await Task.Delay(1300);
                bool pasted = launched && TryPasteIfFirefoxIsForeground();
                ShowMain();
                _status.Text = pasted ? T("state.pasted") : T("state.paste.manual");
            }
            else
            {
                _status.Text = T("state.paste.manual");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static void SetClipboardText(string text)
    {
        if (text.Length > 0) Clipboard.SetText(text);
    }

    private bool OpenFirefox()
    {
        try
        {
            string? firefox = FirefoxLocator.FindFirefox();
            IntPtr existingWindow = FirefoxLocator.FindRunningWindow();
            if (existingWindow != IntPtr.Zero)
            {
                if (NativeHotkey.IsIconic(existingWindow)) NativeHotkey.ShowWindow(existingWindow, 9);
                if (NativeHotkey.GetForegroundWindow() != existingWindow && !NativeHotkey.SetForegroundWindow(existingWindow))
                    throw new InvalidOperationException("Windows did not allow Firefox to take focus.");

                Thread.Sleep(120);
                var clipboardBackup = Clipboard.GetDataObject();
                try
                {
                    SendKeys.SendWait("^l");
                    Clipboard.SetText(FirefoxUrl);
                    SendKeys.SendWait("^v");
                    SendKeys.SendWait("{ENTER}");
                }
                finally
                {
                    try
                    {
                        if (clipboardBackup is not null) Clipboard.SetDataObject(clipboardBackup, true);
                        else Clipboard.Clear();
                    }
                    catch { }
                }
                return true;
            }

            var start = new ProcessStartInfo
            {
                FileName = firefox ?? "firefox.exe",
                Arguments = $"\"{FirefoxUrl}\"",
                UseShellExecute = true
            };
            Process.Start(start);
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, T("error.openFirefox") + "\n\n" + ex.Message, T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
    }

    private static bool TryPasteIfFirefoxIsForeground()
    {
        IntPtr window = NativeHotkey.GetForegroundWindow();
        if (window == IntPtr.Zero) return false;
        NativeHotkey.GetWindowThreadProcessId(window, out uint pid);
        try
        {
            using var process = Process.GetProcessById((int)pid);
            if (!string.Equals(process.ProcessName, "firefox", StringComparison.OrdinalIgnoreCase)) return false;
            SendKeys.SendWait("^v");
            return true;
        }
        catch { return false; }
    }

    private void SetControlsBusy(bool busy)
    {
        _scanButton.Enabled = !busy;
        _translateButton.Enabled = !busy;
        _openFirefoxButton.Enabled = !busy;
        _manageButton.Enabled = !busy;
        _profileCombo.Enabled = !busy;
    }

    private void SaveSettings() => SettingsStore.Save(_settings);

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        NativeHotkey.UnregisterHotKey(Handle, NativeHotkey.HotkeyId);
        _ocrEngine?.Dispose();
        _ocrEngine = null;
        _tray.Visible = false;
        _tray.Dispose();
        base.OnFormClosed(e);
    }
}

internal sealed class SelectionOverlay : Form
{
    private readonly UiLanguage _language;
    private Point _start;
    private Point _current;
    private bool _dragging;
    private Rectangle _selection;

    public SelectionOverlay(UiLanguage language)
    {
        _language = language;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = SystemInformation.VirtualScreen;
        TopMost = true;
        ShowInTaskbar = false;
        BackColor = Color.Black;
        Opacity = 0.30;
        Cursor = Cursors.Cross;
        DoubleBuffered = true;
        KeyPreview = true;
    }

    protected override void OnShown(EventArgs e) { base.OnShown(e); Activate(); Focus(); }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); }
        base.OnKeyDown(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            _start = _current = e.Location;
            _dragging = true;
            Capture = true;
            Invalidate();
        }
        base.OnMouseDown(e);
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (_dragging) { _current = e.Location; Invalidate(); }
        base.OnMouseMove(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (_dragging && e.Button == MouseButtons.Left)
        {
            _current = e.Location;
            var local = Normalize(_start, _current);
            _selection = new Rectangle(Bounds.X + local.X, Bounds.Y + local.Y, local.Width, local.Height);
            _dragging = false;
            Capture = false;
            DialogResult = _selection.Width >= 4 && _selection.Height >= 4 ? DialogResult.OK : DialogResult.Cancel;
            Close();
        }
        base.OnMouseUp(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        string hint = UiText.Get(_language, "overlay.hint");
        using (var font = new Font("Segoe UI", 14F, FontStyle.Bold))
        using (var brush = new SolidBrush(Color.White))
            e.Graphics.DrawString(hint, font, brush, new PointF(24, 22));
        if (!_dragging) return;
        var rect = Normalize(_start, _current);
        using var fill = new SolidBrush(Color.FromArgb(65, 45, 212, 191));
        using var border = new Pen(UiTheme.Primary, 2);
        e.Graphics.FillRectangle(fill, rect);
        e.Graphics.DrawRectangle(border, rect);
    }

    public byte[] CapturePng()
    {
        using var bitmap = new Bitmap(_selection.Width, _selection.Height, PixelFormat.Format32bppArgb);
        using (var graphics = Graphics.FromImage(bitmap))
            graphics.CopyFromScreen(_selection.Location, Point.Empty, _selection.Size, CopyPixelOperation.SourceCopy);
        using var memory = new MemoryStream();
        bitmap.Save(memory, ImageFormat.Png);
        return memory.ToArray();
    }

    private static Rectangle Normalize(Point a, Point b)
    {
        int x = Math.Min(a.X, b.X), y = Math.Min(a.Y, b.Y);
        return new Rectangle(x, y, Math.Abs(a.X - b.X), Math.Abs(a.Y - b.Y));
    }
}

internal static class FirefoxLocator
{
    public static IntPtr FindRunningWindow()
    {
        foreach (var process in Process.GetProcessesByName("firefox"))
        {
            using (process)
            {
                try
                {
                    if (!process.HasExited && process.MainWindowHandle != IntPtr.Zero)
                        return process.MainWindowHandle;
                }
                catch (InvalidOperationException) { }
                catch (System.ComponentModel.Win32Exception) { }
            }
        }
        return IntPtr.Zero;
    }

    public static string? FindFirefox()
    {
        foreach (var hive in new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine })
        {
            foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using var baseKey = RegistryKey.OpenBaseKey(hive, view);
                    using var key = baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe");
                    var value = key?.GetValue(null) as string;
                    if (!string.IsNullOrWhiteSpace(value) && File.Exists(value)) return value;
                }
                catch (SecurityException) { }
                catch (UnauthorizedAccessException) { }
                catch (IOException) { }
            }
        }

        var candidates = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Mozilla Firefox", "firefox.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Mozilla Firefox", "firefox.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Mozilla Firefox", "firefox.exe")
        };
        return candidates.FirstOrDefault(File.Exists);
    }
}

internal static class NativeHotkey
{
    public const int HotkeyId = 0x514A;
    public const int WmHotkey = 0x0312;
    public const uint ModAlt = 0x0001;
    public const uint ModControl = 0x0002;

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, int vk);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
