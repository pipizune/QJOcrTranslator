using System.Diagnostics;
using System.Net.Http;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace QJOcrTranslator;

internal sealed class ModelManagerForm : Form
{
    private static readonly HttpClient Http = CreateHttpClient();
    private readonly UiLanguage _language;
    private readonly Dictionary<string, Label> _statusLabels = new(StringComparer.OrdinalIgnoreCase);
    private readonly Label _status = new();
    private readonly ProgressBar _progress = new();
    private readonly Button _importButton = new();
    private readonly Button _repairButton = new();
    private readonly Button _downloadButton = new();
    private readonly Button _folderButton = new();

    public ModelManagerForm(UiLanguage language)
    {
        _language = language;
        Text = T("manager.title");
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(760, 475);
        BackColor = UiTheme.Background;
        ForeColor = UiTheme.Text;
        Font = new Font("Segoe UI", 9F);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(20),
            ColumnCount = 1,
            RowCount = 7,
            BackColor = UiTheme.Background
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        var title = new Label { Text = T("manager.intro"), Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9.5F, FontStyle.Bold) };
        UiTheme.StyleLabel(title);
        root.Controls.Add(title, 0, 0);

        AddAssetRow(root, 1, T("manager.rec"), ModelCatalog.V6Recognizer);
        AddAssetRow(root, 2, T("manager.det"), ModelCatalog.V6Detector);
        AddAssetRow(root, 3, T("manager.dict"), ModelCatalog.V6Dictionary);

        var privacy = new Label { Text = T("manager.privacy"), Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
        UiTheme.StyleLabel(privacy, muted: true);
        root.Controls.Add(privacy, 0, 4);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, BackColor = Color.Transparent, Padding = new Padding(0, 4, 0, 0) };
        _importButton.Text = T("manager.import");
        _importButton.Size = new Size(170, 38);
        _importButton.Click += async (_, _) => await ImportRecognizerAsync();
        UiTheme.StyleButton(_importButton, primary: true);
        _repairButton.Text = T("manager.download.missing");
        _repairButton.Size = new Size(175, 38);
        _repairButton.Click += async (_, _) => await DownloadMissingCompanionsAsync();
        UiTheme.StyleButton(_repairButton);
        _downloadButton.Text = T("manager.download.all");
        _downloadButton.Size = new Size(195, 38);
        _downloadButton.Click += async (_, _) => await DownloadAllAsync();
        UiTheme.StyleButton(_downloadButton);
        _folderButton.Text = T("manager.openFolder");
        _folderButton.Size = new Size(135, 38);
        _folderButton.Click += (_, _) => OpenModelFolder();
        UiTheme.StyleButton(_folderButton);
        buttons.Controls.AddRange(new Control[] { _importButton, _repairButton, _downloadButton, _folderButton });
        root.Controls.Add(buttons, 0, 5);

        var bottom = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Color.Transparent };
        bottom.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
        bottom.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
        _status.Text = T("manager.status.missing");
        UiTheme.StyleLabel(_status, muted: true);
        _status.AutoEllipsis = true;
        _progress.Dock = DockStyle.Fill;
        _progress.Style = ProgressBarStyle.Continuous;
        _progress.Visible = false;
        bottom.Controls.Add(_status, 0, 0);
        bottom.Controls.Add(_progress, 0, 1);
        root.Controls.Add(bottom, 0, 6);

        Shown += async (_, _) => await RefreshStatusAsync();
    }

    private void AddAssetRow(TableLayoutPanel root, int row, string description, RemoteModelAsset asset)
    {
        var panel = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.Surface, Padding = new Padding(12, 7, 12, 7), Margin = new Padding(0, 0, 0, 6) };
        var name = new Label { Text = $"{description}   ·   {asset.FileName}", Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
        UiTheme.StyleLabel(name);
        var status = new Label { Text = "…", Dock = DockStyle.Right, Width = 225, TextAlign = ContentAlignment.MiddleRight, AutoEllipsis = true };
        UiTheme.StyleLabel(status, muted: true);
        panel.Controls.Add(name);
        panel.Controls.Add(status);
        root.Controls.Add(panel, 0, row);
        _statusLabels[asset.FileName] = status;
    }

    private string T(string key) => UiText.Get(_language, key);

    private async Task RefreshStatusAsync()
    {
        SetBusy(true);
        try
        {
            Directory.CreateDirectory(ModelCatalog.V6Directory);
            bool allVerified = true;
            foreach (var asset in new[] { ModelCatalog.V6Recognizer, ModelCatalog.V6Detector, ModelCatalog.V6Dictionary })
            {
                var label = _statusLabels[asset.FileName];
                string path = ModelCatalog.PathFor(asset);
                if (!File.Exists(path) || new FileInfo(path).Length == 0)
                {
                    allVerified = false;
                    label.Text = T("manager.status.missing");
                    label.ForeColor = UiTheme.Warning;
                    continue;
                }

                string hash = await ComputeSha256Async(path);
                bool verified = string.Equals(hash, asset.Sha256, StringComparison.OrdinalIgnoreCase);
                allVerified &= verified;
                double mib = new FileInfo(path).Length / 1048576d;
                label.Text = $"{mib:F1} MiB · {T(verified ? "manager.status.verified" : "manager.status.unverified")}";
                label.ForeColor = verified ? UiTheme.Success : UiTheme.Warning;
            }

            bool ready = new[] { ModelCatalog.V6Recognizer, ModelCatalog.V6Detector, ModelCatalog.V6Dictionary }
                .All(a => File.Exists(ModelCatalog.PathFor(a)) && new FileInfo(ModelCatalog.PathFor(a)).Length > 0);
            _status.Text = allVerified ? T("manager.done") : ready ? T("manager.status.unverified") : T("manager.status.missing");
            _status.ForeColor = allVerified ? UiTheme.Success : UiTheme.Warning;
        }
        catch (Exception ex)
        {
            _status.Text = T("manager.download.error").Replace("{0}", ex.Message);
            _status.ForeColor = UiTheme.Error;
        }
        finally { SetBusy(false); }
    }

    private async Task ImportRecognizerAsync()
    {
        string likelyFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "rapidocr model");
        using var dialog = new OpenFileDialog
        {
            Title = T("manager.choose.rec"),
            Filter = T("manager.file.filter"),
            FileName = "PP-OCRv6_rec_medium.onnx",
            InitialDirectory = Directory.Exists(likelyFolder) ? likelyFolder : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            var info = new FileInfo(dialog.FileName);
            if (info.Length < 1_000_000)
            {
                MessageBox.Show(this, T("manager.file.error"), T("dialog.warning"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string hash = await ComputeSha256Async(dialog.FileName);
            if (!string.Equals(hash, ModelCatalog.V6Recognizer.Sha256, StringComparison.OrdinalIgnoreCase))
            {
                string prompt = string.Format(T("manager.hash.warning"), hash, ModelCatalog.V6Recognizer.Sha256);
                if (MessageBox.Show(this, prompt, T("dialog.warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                    return;
            }

            SetBusy(true);
            Directory.CreateDirectory(ModelCatalog.V6Directory);
            string destination = ModelCatalog.PathFor(ModelCatalog.V6Recognizer);
            if (!string.Equals(Path.GetFullPath(dialog.FileName), Path.GetFullPath(destination), StringComparison.OrdinalIgnoreCase))
            {
                string temp = destination + ".importing";
                _status.Text = string.Format(T("manager.loading"), Path.GetFileName(dialog.FileName));
                await using (var source = new FileStream(dialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read, 256 * 1024, useAsync: true))
                await using (var target = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 256 * 1024, useAsync: true))
                    await source.CopyToAsync(target);
                File.Move(temp, destination, overwrite: true);
            }

            _status.Text = T("manager.import.ok");
            await EnsureOfficialAssetAsync(ModelCatalog.V6Detector);
            await EnsureOfficialAssetAsync(ModelCatalog.V6Dictionary);
            await RefreshStatusAsync();
        }
        catch (Exception ex)
        {
            _status.Text = T("manager.download.error").Replace("{0}", ex.Message);
            _status.ForeColor = UiTheme.Error;
            MessageBox.Show(this, string.Format(T("manager.download.error"), ex.Message), T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { SetBusy(false); }
    }

    private async Task DownloadAllAsync()
    {
        if (MessageBox.Show(this, T("manager.size.warning"), T("dialog.warning"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            return;

        try
        {
            SetBusy(true);
            Directory.CreateDirectory(ModelCatalog.V6Directory);
            await EnsureOfficialAssetAsync(ModelCatalog.V6Detector);
            await EnsureOfficialAssetAsync(ModelCatalog.V6Dictionary);
            await EnsureOfficialAssetAsync(ModelCatalog.V6Recognizer);
            await RefreshStatusAsync();
            _status.Text = T("manager.download.done");
        }
        catch (Exception ex)
        {
            _status.Text = string.Format(T("manager.download.error"), ex.Message);
            _status.ForeColor = UiTheme.Error;
            MessageBox.Show(this, string.Format(T("manager.download.error"), ex.Message), T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { SetBusy(false); }
    }

    private async Task DownloadMissingCompanionsAsync()
    {
        try
        {
            SetBusy(true);
            Directory.CreateDirectory(ModelCatalog.V6Directory);
            await EnsureOfficialAssetAsync(ModelCatalog.V6Detector);
            await EnsureOfficialAssetAsync(ModelCatalog.V6Dictionary);
            await RefreshStatusAsync();
            _status.Text = T("manager.download.done");
        }
        catch (Exception ex)
        {
            _status.Text = string.Format(T("manager.download.error"), ex.Message);
            _status.ForeColor = UiTheme.Error;
            MessageBox.Show(this, string.Format(T("manager.download.error"), ex.Message), T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { SetBusy(false); }
    }

    private async Task EnsureOfficialAssetAsync(RemoteModelAsset asset)
    {
        string target = ModelCatalog.PathFor(asset);
        if (File.Exists(target))
        {
            string existingHash = await ComputeSha256Async(target);
            if (string.Equals(existingHash, asset.Sha256, StringComparison.OrdinalIgnoreCase)) return;
        }

        _status.Text = string.Format(T("manager.loading"), asset.FileName);
        _status.ForeColor = UiTheme.Primary;
        string temp = target + ".download";
        try
        {
            using var response = await Http.GetAsync(asset.Url, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();
            long? total = response.Content.Headers.ContentLength;
            await using var input = await response.Content.ReadAsStreamAsync();
            await using var output = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 128 * 1024, useAsync: true);
            var buffer = new byte[128 * 1024];
            long readTotal = 0;
            int read;
            while ((read = await input.ReadAsync(buffer)) > 0)
            {
                await output.WriteAsync(buffer.AsMemory(0, read));
                readTotal += read;
                if (total is > 0)
                {
                    _progress.Value = (int)Math.Clamp(readTotal * 100 / total.Value, 0, 100);
                    _status.Text = string.Format(T("manager.progress"), (readTotal / 1048576d).ToString("F1"), (total.Value / 1048576d).ToString("F1"));
                }
            }
            await output.FlushAsync();

            string actual = await ComputeSha256Async(temp);
            if (!string.Equals(actual, asset.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"SHA-256 mismatch for {asset.FileName}: {actual}");
            File.Move(temp, target, overwrite: true);
            _progress.Value = 0;
        }
        finally
        {
            if (File.Exists(temp)) File.Delete(temp);
        }
    }

    private void OpenModelFolder()
    {
        try
        {
            Directory.CreateDirectory(ModelCatalog.V6Directory);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{ModelCatalog.V6Directory}\"") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, T("error.title"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void SetBusy(bool busy)
    {
        _importButton.Enabled = !busy;
        _repairButton.Enabled = !busy;
        _downloadButton.Enabled = !busy;
        _folderButton.Enabled = !busy;
        UseWaitCursor = busy;
        _progress.Visible = busy;
    }

    private static async Task<string> ComputeSha256Async(string path)
    {
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 256 * 1024, useAsync: true);
        using var sha = SHA256.Create();
        byte[] hash = await sha.ComputeHashAsync(stream);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static HttpClient CreateHttpClient()
    {
        var client = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd("QJOcrTranslator/1.0 (+https://github.com/)");
        return client;
    }
}
