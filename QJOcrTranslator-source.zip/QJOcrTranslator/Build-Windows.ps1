#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'Chưa tìm thấy dotnet SDK. Cài .NET 8 SDK trước, rồi mở terminal mới và chạy lại.'
}

& .\Get-LanguageModels.ps1

if (Test-Path .\publish) { Remove-Item .\publish -Recurse -Force }

Write-Host 'Đang restore/build ứng dụng Windows x64...' -ForegroundColor Cyan
dotnet publish .\QJOcrTranslator.csproj -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableWindowsTargeting=true -o .\publish
if ($LASTEXITCODE -ne 0) { throw 'dotnet publish thất bại.' }

Get-ChildItem .\publish -Filter '*.lib' -File | Remove-Item -Force
Copy-Item (Join-Path $PSScriptRoot '..\README.md') .\publish\README.md -Force
Copy-Item (Join-Path $PSScriptRoot '..\README-VI.md') .\publish\README-VI.md -Force
Copy-Item (Join-Path $PSScriptRoot '..\LICENSE') .\publish\LICENSE -Force
Copy-Item (Join-Path $PSScriptRoot '..\ThirdPartyLicenses') .\publish\ThirdPartyLicenses -Recurse -Force
New-Item -ItemType Directory -Force -Path .\publish\docs | Out-Null
Copy-Item (Join-Path $PSScriptRoot '..\docs\model-assets.md') .\publish\docs\model-assets.md -Force

Write-Host ''
Write-Host 'Hoàn tất: .\publish\QJOcrTranslator.exe' -ForegroundColor Green
Write-Host 'Cần .NET 8 Desktop Runtime x64 trên máy chạy. Giữ nguyên thư mục publish\models\v5 cạnh EXE.'
