using RapidOcrNet;

namespace QJOcrTranslator;

internal enum OcrProfileId
{
    V5Latin,
    V5Cjk,
    V5Korean,
    V5Russian,
    V6Medium
}

internal sealed record OcrProfile(OcrProfileId Id, string IdText, bool IsV6)
{
    public string Name(UiLanguage language) => UiText.ProfileName(language, IdText);
    public string Description(UiLanguage language) => UiText.ProfileDescription(language, IdText);
}

internal sealed record OcrPaths(string Detector, string Classifier, string Recognizer, string Dictionary);

internal sealed record RemoteModelAsset(string FileName, string Url, string Sha256, bool Large = false);

internal static class ModelCatalog
{
    private const string ModelScope = "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.10.0";

    public static readonly IReadOnlyList<OcrProfile> Profiles = new[]
    {
        new OcrProfile(OcrProfileId.V5Latin, "v5-latin", false),
        new OcrProfile(OcrProfileId.V5Cjk, "v5-cjk", false),
        new OcrProfile(OcrProfileId.V5Korean, "v5-korean", false),
        new OcrProfile(OcrProfileId.V5Russian, "v5-russian", false),
        new OcrProfile(OcrProfileId.V6Medium, "v6-medium", true)
    };

    public static readonly RemoteModelAsset V6Detector = new(
        "PP-OCRv6_det_medium.onnx",
        $"{ModelScope}/onnx/PP-OCRv6/det/PP-OCRv6_det_medium.onnx",
        "92078b7355007ccfffcd4c8cd441a3afd4538904d06881b29a155e1e679907c2");

    public static readonly RemoteModelAsset V6Recognizer = new(
        "PP-OCRv6_rec_medium.onnx",
        $"{ModelScope}/onnx/PP-OCRv6/rec/PP-OCRv6_rec_medium.onnx",
        "eef444829dbbe18d7fea59a3f6eb75647518d2b3a9568d27c92e42940204894b",
        Large: true);

    public static readonly RemoteModelAsset V6Dictionary = new(
        "ppocrv6_medium_dict.txt",
        $"{ModelScope}/paddle/PP-OCRv6/rec/PP-OCRv6_rec_medium/ppocrv6_dict.txt",
        "b5f2bfe2bdd9448429e3e82b51c789775d9b42f2403d082b00662eb77e401c5d");

    public static string AppDataRoot => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "QJOcrTranslator");

    public static string V5Directory => Path.Combine(AppContext.BaseDirectory, "models", "v5");
    public static string V6Directory => Path.Combine(AppDataRoot, "models", "v6");

    public static string PathFor(RemoteModelAsset asset) => Path.Combine(V6Directory, asset.FileName);

    public static OcrPaths Resolve(OcrProfile profile)
    {
        string v5 = V5Directory;
        string detector = Path.Combine(v5, "ch_PP-OCRv5_mobile_det.onnx");
        string classifier = Path.Combine(v5, "ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx");

        if (profile.Id == OcrProfileId.V6Medium)
        {
            return new OcrPaths(
                PathFor(V6Detector), classifier,
                PathFor(V6Recognizer), PathFor(V6Dictionary));
        }

        var (recognizer, dictionary) = profile.Id switch
        {
            OcrProfileId.V5Cjk => ("ch_PP-OCRv5_rec_mobile.onnx", "ppocrv5_dict.txt"),
            OcrProfileId.V5Korean => ("korean_PP-OCRv5_rec_mobile.onnx", "ppocrv5_korean_dict.txt"),
            OcrProfileId.V5Russian => ("eslav_PP-OCRv5_rec_mobile.onnx", "ppocrv5_eslav_dict.txt"),
            _ => ("latin_PP-OCRv5_rec_mobile_infer.onnx", "ppocrv5_latin_dict.txt")
        };

        return new OcrPaths(detector, classifier, Path.Combine(v5, recognizer), Path.Combine(v5, dictionary));
    }

    public static bool ArePathsPresent(OcrPaths paths, out string missing)
    {
        var absent = new[] { paths.Detector, paths.Classifier, paths.Recognizer, paths.Dictionary }
            .Where(p => !File.Exists(p) || new FileInfo(p).Length == 0)
            .Select(Path.GetFileName)
            .ToArray();
        missing = string.Join(", ", absent);
        return absent.Length == 0;
    }

    public static OcrProfile GetById(string? id) =>
        Profiles.FirstOrDefault(p => string.Equals(p.IdText, id, StringComparison.OrdinalIgnoreCase)) ?? Profiles[0];

    public static RapidOcrModelSet CreateV6ModelSet(OcrPaths paths) => RapidOcrModelSet.PPOCRv6Medium with
    {
        DetModelPath = paths.Detector,
        ClsModelPath = paths.Classifier,
        RecModelPath = paths.Recognizer,
        KeysPath = paths.Dictionary
    };
}
