# OCR model assets

> **Version-specific snapshot, verified 2026-10-13:** RapidOcrNet 4.2.0 and RapidOCR ModelScope tag `v3.10.0`. Recheck upstream routes, hashes, package API, and language coverage before each new release; do not treat these values as timeless.

## PP-OCRv6 Medium: required files

`PP-OCRv6_rec_medium.onnx` alone is **not** a complete OCR pipeline. RapidOcrNet's v6 preset needs its matching detector and character dictionary. The PP-OCRv5 orientation classifier shipped with the app is reused.

| Asset | Local filename expected by RapidOcrNet | Official source filename/path | SHA-256 |
|---|---|---|---|
| Medium detector | `PP-OCRv6_det_medium.onnx` | [ModelScope ONNX detector](https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.10.0/onnx/PP-OCRv6/det/PP-OCRv6_det_medium.onnx) | `92078b7355007ccfffcd4c8cd441a3afd4538904d06881b29a155e1e679907c2` |
| Medium recognizer | `PP-OCRv6_rec_medium.onnx` | [ModelScope ONNX recognizer](https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.10.0/onnx/PP-OCRv6/rec/PP-OCRv6_rec_medium.onnx) | `eef444829dbbe18d7fea59a3f6eb75647518d2b3a9568d27c92e42940204894b` |
| Medium dictionary/keys | `ppocrv6_medium_dict.txt` | [ModelScope dictionary](https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.10.0/paddle/PP-OCRv6/rec/PP-OCRv6_rec_medium/ppocrv6_dict.txt) — upstream filename is `ppocrv6_dict.txt` | `b5f2bfe2bdd9448429e3e82b51c789775d9b42f2403d082b00662eb77e401c5d` |
| Orientation classifier | `ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx` | Bundled PP-OCRv5 mobile asset from RapidOcrNet 4.2.0 | Shared asset; verify against the pinned package/source manifest |

**Answer to the missing-file question:** the dictionary exists upstream, but not under the local alias `ppocrv6_medium_dict.txt`. The app saves/renames the official `ppocrv6_dict.txt` to the exact filename RapidOcrNet's Medium preset expects. A dictionary is mandatory even if Vietnamese is not a target: it maps model output class IDs back to characters. Do not substitute a v5 dictionary or append characters manually; changing dictionary order breaks the recognizer's class-index mapping.

The app stores imported/downloaded v6 assets under `%LOCALAPPDATA%\QJOcrTranslator\models\v6`. Use **Download missing files** to fetch detector/dictionary without downloading an already-installed recognizer again, or **Download full v6 Medium** if no recognizer is installed. Downloads are user-initiated and SHA-256 checked.

## Language coverage and limitations

PaddleOCR's current PP-OCRv6 documentation lists Medium/Small as 50 languages: Simplified/Traditional Chinese, English, Japanese, and 46 Latin-script languages. Korean and Russian are not listed; use the app's dedicated PP-OCRv5 Korean/East-Slavic profiles when reliable Hangul/Cyrillic recognition is required. Users may still test v6 on out-of-list scripts, but do not promise accuracy based only on model size or parameter count.

**Vietnamese dictionary caveat:** PaddleOCR issue [#18254](https://github.com/PaddlePaddle/PaddleOCR/issues/18254) reports that the v6 Medium/Small dictionary omits 88 of the 196 single-character forms in the complete Vietnamese charset, including many tone-marked vowels. The issue's maintainer confirmed the discrepancy and explained that the model must be re-exported/trained with matching class indices; simply swapping in `vi_dict.txt` is not safe. We downloaded and compared the official v3.10.0 ModelScope dictionary with PaddleOCR's complete `vi_dict.txt` reference on 2026-10-13: 18,708 v6 dictionary entries, 196 Vietnamese reference characters, 88 absent. This does not affect the user's main source-language workflow (Chinese/Japanese/English to Vietnamese); use v5 Latin if OCR-ing Vietnamese text itself.

PP-OCRv6 Medium is the largest/heaviest option in this app and may take longer/more RAM to initialize than v5 mobile. The app caps ONNX CPU inference at one thread and keeps only the active model profile loaded.

## Firefox tab reuse

When Firefox is already running, the app focuses its existing window, puts `about:translations#src=detect&trg=vi` in the address bar, and submits it rather than launching the URL into a new tab. Firefox's address bar can surface open tabs and a “Switch to Tab” suggestion; matching an existing translation tab depends on the user's Firefox autocomplete/tab-suggestion settings. If no matching tab is surfaced, this keyboard fallback reuses the current tab, so users who want to preserve another page should open the translation tab once first. Auto-paste into the privileged translation page remains best-effort and should be tested on the target Windows/Firefox version.

The app deliberately does **not** enable Firefox Remote Agent/remote-debugging. Mozilla documents its `--remote-debugging-port` listener as opt-in; the Remote Agent may only ship in Nightly builds, and Mozilla warns that it has no authentication/encryption. Do not expose that port to untrusted networks.

## References

- [RapidOcrNet README and model presets](https://github.com/BobLd/RapidOcrNet)
- [RapidOCR default model configuration](https://github.com/RapidAI/RapidOCR/blob/main/python/rapidocr/default_models.yaml)
- [PaddleOCR PP-OCRv6 language coverage](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/version3.x/algorithm/PP-OCRv6/PP-OCRv6.en.md)
- [PaddleOCR issue #18254: Vietnamese characters missing from v6 dictionaries](https://github.com/PaddlePaddle/PaddleOCR/issues/18254)
- [Mozilla Support: Firefox address-bar search, including Tabs (%) and open-tab suggestions](https://support.mozilla.org/en-US/kb/search-firefox-address-bar)
- [Mozilla Remote Agent build notes](https://firefox-source-docs.mozilla.org/remote/Building.html)
- [Mozilla Remote Agent security](https://firefox-source-docs.mozilla.org/remote/Security.html)
